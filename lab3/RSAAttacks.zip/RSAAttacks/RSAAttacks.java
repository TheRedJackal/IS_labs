import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.RSAPrivateKeySpec;

public class RSAAttacks {

    private static final BigInteger ONE = new BigInteger("1");

    /**
     * Tries to find the message assuming that the public exponent is equal to 3
     * and that the ciphertexts contain the same message encrypted with different
     * public keys.
     *
     * @param c1 first ciphertext
     * @param m1 modulus of first public key
     * @param c2 second ciphertext
     * @param m2 modulus of second public key
     * @param c3 third ciphertext
     * @param m3 modulus of third public key
     * @return the candidate message or null if algorithm fails
     */
    public static String tryLowExponentAttack(
            BigInteger c1, BigInteger m1,
            BigInteger c2, BigInteger m2,
            BigInteger c3, BigInteger m3) {
        try {

            //*** YOUR CODE ***

        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Tries to find the private key corresponding to the first modulus assuming
     * that the two provided moduli have a common factor.
     *
     * @param m1 first modulus
     * @param m2 second modulus
     * @param e1 public exponent corresponding to the first modulus
     * @return the candidate private key or null if algorithm fails
     */
    public static RSAPrivateKey tryCommonFactorAttack(
            BigInteger m1, BigInteger m2, BigInteger e1) {
        try {

            //*** YOUR CODE ***

        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Cracking Application.
     */
    public static void main(String[] args) {
        try {
            // ** Load a public key from file and get its modulus and exponent:
            // RSAPublicKey samplePublicKey = RSAEncryptionUtil.loadRSAPublicKey("sample.pub");
            // BigInteger sampleModulus = samplePublicKey.getModulus(); 
            // BigInteger sampleExponent = samplePublicKey.getPublicExponent(); 
            
            // ** Load ciphertext from file into a BigInteger:
            // BigInteger sampleCipherText = RSAEncryptionUtil.loadCiphertext("message-sample.enc");
            
            // ** Create an RSAPrivateKey from the modulus and private exponent:
            // RSAPrivateKeySpec keySpec = new RSAPrivateKeySpec(modulus, privateExponent);
            // RSAPrivateKey privateKey = (RSAPrivateKey) KeyFactory.getInstance(RSAEncryptionUtil.ALGORITHM).generatePrivate(keySpec);

            // ** Decrypt a ciphertext with a private key:
            // String plaintext = RSAEncryptionUtil.decrypt(sampleCipherText.toByteArray(), privateKey);

            // ** Convert a message that is represented as a BigInteger into a byte array and from 
            // ** this, create a string by interpreting the bytes as US-ASCII code
            // BigInteger messageAsBigInteger = ...;
            // String message = new String(messageAsBigInteger.toByteArray(), StandardCharsets.US_ASCII);
            
            //*** YOUR CODE ***
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
